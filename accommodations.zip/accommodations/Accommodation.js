const filterButtons = document.querySelectorAll(".filter-btn");
const categoryBlocks = document.querySelectorAll(".category-block");
const guestFilter = document.querySelector("#filter-guests");
const budgetFilter = document.querySelector("#filter-budget");
const ratingFilter = document.querySelector("#filter-rating");
const popularityFilter = document.querySelector("#filter-popularity");
const sortFilter = document.querySelector("#filter-sort");
const amenityFilters = document.querySelectorAll('input[name="amenity"]');
const filterResults = document.querySelector("#filter-results");
const filterEmpty = document.querySelector("#filter-empty");
const filterModal = document.querySelector("#filter-modal");
const openFiltersButton = document.querySelector("#open-filters");
const closeFiltersButton = document.querySelector("#close-filters");
const filterCount = document.querySelector("#filter-count");
const availabilityModal = document.querySelector("#availability-modal");
const openAvailabilityButton = document.querySelector("#open-availability");
const closeAvailabilityButton = document.querySelector("#close-availability");
const availabilityCount = document.querySelector("#availability-count");
const calendarMonthLabel = document.querySelector("#calendar-month");
const calendarDays = document.querySelector("#calendar-days");
const calendarSelection = document.querySelector("#calendar-selection");
const applyAvailabilityButton = document.querySelector("#apply-availability");
const monthFormatter = new Intl.DateTimeFormat("en", { month: "long", year: "numeric" });
const dateFormatter = new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" });
const demoBookedOffsets = [
    [2, 3, 11],
    [4, 5, 11],
    [6, 7, 11],
    [8, 9, 11],
    [10, 11, 12],
    [13, 14, 11],
    [15, 16, 17, 11],
    [5, 6, 11, 18]
];
let selectedCategory = "all";
const bookingModal = document.querySelector("#booking-modal");
const bookingForm = document.querySelector("#booking-form");
const bookingMessage = document.querySelector("#booking-message");
const closeModalButton = document.querySelector("#close-booking");
const modalTitle = document.querySelector("#modal-title");
const modalPrice = document.querySelector("#modal-price");
const checkInInput = document.querySelector("#check-in");
const checkOutInput = document.querySelector("#check-out");
const guestCountInput = document.querySelector("#guest-count");
const guestLimit = document.querySelector("#guest-limit");
const petCountGroup = document.querySelector("#pet-count-group");
const petCountInput = document.querySelector("#pet-count");
const summaryNights = document.querySelector("#summary-nights");
const summaryRoomRate = document.querySelector("#summary-room-rate");
const summaryExtraFees = document.querySelector("#summary-extra-fees");
const summaryTotal = document.querySelector("#summary-total");
const decreaseGuestsButton = document.querySelector("#decrease-guests");
const increaseGuestsButton = document.querySelector("#increase-guests");
const currency = new Intl.NumberFormat("en-PH");
let currentRoom;
let lastFocusedElement;
let calendarMonth = new Date();
calendarMonth.setDate(1);
let availabilityCheckIn = "";
let availabilityCheckOut = "";
let availabilityRangeActive = false;

document.querySelectorAll(".room-card").forEach((card, index) => {
    card.dataset.originalOrder = String(index);
});

function showAllRooms() {
    selectedCategory = "all";
    filterButtons.forEach((button) => {
        button.setAttribute("aria-pressed", String(button.dataset.filter === selectedCategory));
    });
    applyRoomFilters();
}

function getRoomPrice(card, guests) {
    const bookButton = card.querySelector("[data-book-room]");
    const basePrice = Number(bookButton.dataset.price);
    const includedGuests = Number(bookButton.dataset.includedGuests);
    const extraPrice = Number(bookButton.dataset.extraPrice);
    return basePrice + (guests === null ? 0 : Math.max(0, guests - includedGuests) * extraPrice);
}

function normalizeAmenity(value) {
    return value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function getDayOffset(dateString) {
    const [year, month, day] = dateString.split("-").map(Number);
    const dateInDays = Date.UTC(year, month - 1, day);
    const [todayYear, todayMonth, todayDay] = localDateString().split("-").map(Number);
    const todayInDays = Date.UTC(todayYear, todayMonth - 1, todayDay);
    return Math.round((dateInDays - todayInDays) / 86400000);
}

function isRoomAvailableOn(card, dateString) {
    const dayOffset = getDayOffset(dateString);
    if (dayOffset < 0) {
        return false;
    }

    const scheduleDay = dayOffset % 21;
    const roomIndex = Number(card.dataset.originalOrder);
    return !(demoBookedOffsets[roomIndex] || []).includes(scheduleDay);
}

function isRoomAvailableForStay(card, checkIn, checkOut) {
    for (let offset = getDayOffset(checkIn); offset < getDayOffset(checkOut); offset += 1) {
        const [year, month, day] = localDateString().split("-").map(Number);
        const stayDate = new Date(year, month - 1, day + offset);
        if (!isRoomAvailableOn(card, localDateString(stayDate))) {
            return false;
        }
    }
    return true;
}

function getAvailabilityForDate(dateString) {
    const allRooms = [...document.querySelectorAll(".room-card")];
    return {
        available: allRooms.filter((card) => isRoomAvailableOn(card, dateString)).length,
        total: allRooms.length
    };
}

function applyRoomFilters() {
    const guestValue = guestFilter.value.trim();
    const guests = guestValue ? Number(guestValue) : null;
    const budget = budgetFilter.value ? Number(budgetFilter.value) : null;
    const minimumRating = ratingFilter.value ? Number(ratingFilter.value) : null;
    const minimumPopularity = popularityFilter.value ? Number(popularityFilter.value) : null;
    const selectedAmenities = [...amenityFilters]
        .filter((checkbox) => checkbox.checked)
        .map((checkbox) => checkbox.value.toLowerCase());
    const sortOrder = sortFilter.value;

    if (guests !== null && (!Number.isInteger(guests) || guests < 1 || guests > 40)) {
        guestFilter.setCustomValidity("Enter a number of persons from 1 to 40.");
        filterResults.textContent = "Enter a number of persons from 1 to 40 to filter rooms.";
        return;
    }

    guestFilter.setCustomValidity("");
    let visibleRooms = 0;
    let activeFilterCount = selectedAmenities.length;
    activeFilterCount += Number(Boolean(guestValue));
    activeFilterCount += Number(Boolean(budgetFilter.value));
    activeFilterCount += Number(Boolean(ratingFilter.value));
    activeFilterCount += Number(Boolean(popularityFilter.value));
    filterCount.textContent = String(activeFilterCount);
    filterCount.hidden = activeFilterCount === 0;

    categoryBlocks.forEach((block) => {
        const categoryMatches = selectedCategory === "all" || block.dataset.category === selectedCategory;
        const roomCards = [...block.querySelectorAll(".room-card")];
        let visibleInBlock = 0;

        roomCards.forEach((card) => {
            const bookButton = card.querySelector("[data-book-room]");
            const maximumGuests = Number(bookButton.dataset.maxGuests);
            const rating = Number(card.dataset.rating);
            const popularity = Number(card.dataset.popularity);
            const guestCountMatches = guests === null || guests <= maximumGuests;
            const effectivePrice = getRoomPrice(card, guests);
            const budgetMatches = budget === null || effectivePrice <= budget;
            const ratingMatches = minimumRating === null || rating >= minimumRating;
            const popularityMatches = minimumPopularity === null || popularity >= minimumPopularity;
            const availabilityMatches = !availabilityRangeActive
                || isRoomAvailableForStay(card, availabilityCheckIn, availabilityCheckOut);
            const roomAmenities = [...card.querySelectorAll(".amenity")]
                .map((amenity) => normalizeAmenity(amenity.textContent));
            const amenitiesMatch = selectedAmenities.every((selectedAmenity) =>
                roomAmenities.some((roomAmenity) =>
                    ` ${roomAmenity} `.includes(` ${normalizeAmenity(selectedAmenity)} `)
                )
            );
            const matches = categoryMatches && guestCountMatches && budgetMatches
                && ratingMatches && popularityMatches && amenitiesMatch && availabilityMatches;

            card.hidden = !matches;
            if (matches) {
                visibleInBlock += 1;
            }
        });

        roomCards.sort((first, second) => {
            if (sortOrder === "popular") {
                return Number(second.dataset.popularity) - Number(first.dataset.popularity);
            }
            if (sortOrder === "rating") {
                return Number(second.dataset.rating) - Number(first.dataset.rating)
                    || Number(second.dataset.popularity) - Number(first.dataset.popularity);
            }
            if (sortOrder === "price-low") {
                return getRoomPrice(first, guests) - getRoomPrice(second, guests);
            }
            if (sortOrder === "price-high") {
                return getRoomPrice(second, guests) - getRoomPrice(first, guests);
            }
            return Number(first.dataset.originalOrder) - Number(second.dataset.originalOrder);
        });
        roomCards.forEach((card) => block.querySelector(".rooms-grid").append(card));

        block.hidden = visibleInBlock === 0;
        visibleRooms += visibleInBlock;
    });

    filterEmpty.hidden = visibleRooms > 0;
    filterEmpty.textContent = availabilityRangeActive
        ? "No rooms are available for those dates with the selected filters. Try changing your stay dates or filters."
        : "No rooms match those filters. Try changing your selections.";
    filterResults.textContent = availabilityRangeActive
        ? `${visibleRooms} ${visibleRooms === 1 ? "room is" : "rooms are"} available from ${dateFormatter.format(new Date(`${availabilityCheckIn}T00:00:00`))} to ${dateFormatter.format(new Date(`${availabilityCheckOut}T00:00:00`))}.`
        : `${visibleRooms} ${visibleRooms === 1 ? "room matches" : "rooms match"} your preferences.`;
}

function openFilterModal() {
    filterModal.classList.add("is-open");
    filterModal.setAttribute("aria-hidden", "false");
    openFiltersButton.setAttribute("aria-expanded", "true");
    closeFiltersButton.focus();
}

function closeFilterModal() {
    filterModal.classList.remove("is-open");
    filterModal.setAttribute("aria-hidden", "true");
    openFiltersButton.setAttribute("aria-expanded", "false");
    openFiltersButton.focus();
}

function updateCalendarSelection() {
    applyAvailabilityButton.disabled = !availabilityCheckIn || !availabilityCheckOut;
    calendarSelection.classList.remove("has-no-availability");

    if (!availabilityCheckIn) {
        calendarSelection.textContent = "Select a check-in date.";
        return;
    }

    if (!availabilityCheckOut) {
        calendarSelection.textContent = `Check-in: ${dateFormatter.format(new Date(`${availabilityCheckIn}T00:00:00`))}. Select a check-out date.`;
        return;
    }

    const availableRooms = [...document.querySelectorAll(".room-card")]
        .filter((card) => isRoomAvailableForStay(card, availabilityCheckIn, availabilityCheckOut)).length;
    calendarSelection.textContent = availableRooms > 0
        ? `${availableRooms} ${availableRooms === 1 ? "room is" : "rooms are"} available for these dates.`
        : "No rooms are available for this date range.";
    calendarSelection.classList.toggle("has-no-availability", availableRooms === 0);
}

function renderAvailabilityCalendar() {
    const year = calendarMonth.getFullYear();
    const month = calendarMonth.getMonth();
    const firstOfMonth = new Date(year, month, 1);
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const currentMonth = new Date();
    currentMonth.setDate(1);
    calendarMonthLabel.textContent = monthFormatter.format(firstOfMonth);
    document.querySelector("#previous-month").disabled = firstOfMonth <= currentMonth;
    calendarDays.replaceChildren();

    for (let blankDay = 0; blankDay < (firstOfMonth.getDay() + 6) % 7; blankDay += 1) {
        const blankCell = document.createElement("span");
        blankCell.setAttribute("aria-hidden", "true");
        calendarDays.append(blankCell);
    }

    for (let day = 1; day <= daysInMonth; day += 1) {
        const date = new Date(year, month, day);
        const dateString = localDateString(date);
        const availability = getAvailabilityForDate(dateString);
        const isAvailable = availability.available > 0;
        const isSelected = dateString === availabilityCheckIn || dateString === availabilityCheckOut;
        const isInRange = availabilityCheckIn && availabilityCheckOut
            && dateString > availabilityCheckIn && dateString < availabilityCheckOut;
        const dayButton = document.createElement("button");
        const isPastDate = getDayOffset(dateString) < 0;

        dayButton.type = "button";
        dayButton.className = `calendar-day ${isAvailable ? "is-available" : "is-fully-booked"}`;
        if (isSelected) {
            dayButton.classList.add("is-selected");
        }
        if (isInRange) {
            dayButton.classList.add("is-in-range");
        }
        dayButton.dataset.date = dateString;
        dayButton.disabled = isPastDate;
        dayButton.setAttribute("aria-pressed", String(isSelected));
        dayButton.setAttribute(
            "aria-label",
            `${dateFormatter.format(date)}, ${isAvailable ? `${availability.available} of ${availability.total} rooms available` : "fully booked"}${isSelected ? ", selected" : ""}`
        );
        dayButton.innerHTML = `<strong>${day}</strong><small>${isAvailable ? `${availability.available} rooms` : "Booked"}</small>`;
        calendarDays.append(dayButton);
    }
}

function openAvailabilityModal() {
    if (availabilityCheckIn) {
        calendarMonth = new Date(`${availabilityCheckIn}T00:00:00`);
        calendarMonth.setDate(1);
    } else {
        calendarMonth = new Date();
        calendarMonth.setDate(1);
    }
    renderAvailabilityCalendar();
    updateCalendarSelection();
    availabilityModal.classList.add("is-open");
    availabilityModal.setAttribute("aria-hidden", "false");
    openAvailabilityButton.setAttribute("aria-expanded", "true");
    closeAvailabilityButton.focus();
}

function closeAvailabilityModal() {
    availabilityModal.classList.remove("is-open");
    availabilityModal.setAttribute("aria-hidden", "true");
    openAvailabilityButton.setAttribute("aria-expanded", "false");
    openAvailabilityButton.focus();
}

function localDateString(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

function nextDateString(value) {
    const date = value ? new Date(`${value}T00:00:00`) : new Date();
    date.setDate(date.getDate() + 1);
    return localDateString(date);
}

function getNightCount() {
    if (!checkInInput.value || !checkOutInput.value) {
        return 0;
    }

    const [startYear, startMonth, startDay] = checkInInput.value.split("-").map(Number);
    const [endYear, endMonth, endDay] = checkOutInput.value.split("-").map(Number);
    return (Date.UTC(endYear, endMonth - 1, endDay) - Date.UTC(startYear, startMonth - 1, startDay)) / 86400000;
}

function updateDateLimits() {
    checkInInput.min = localDateString();
    checkOutInput.min = nextDateString(checkInInput.value);
    checkOutInput.setCustomValidity("");

    if (checkOutInput.value && checkOutInput.value < checkOutInput.min) {
        checkOutInput.value = "";
    }
}

function updateBookingSummary() {
    if (!currentRoom) {
        return;
    }

    const guests = Number(guestCountInput.value);
    const extraGuests = Math.max(0, guests - currentRoom.includedGuests);
    const nights = getNightCount();
    const roomTotal = currentRoom.price * Math.max(0, nights);
    const extraFees = extraGuests * currentRoom.extraPrice * Math.max(0, nights);
    const grandTotal = roomTotal + extraFees;

    modalPrice.textContent = `Php ${currency.format(currentRoom.price + extraGuests * currentRoom.extraPrice)} per night for ${guests} ${guests === 1 ? "person" : "persons"}.`;
    if (extraGuests > 0) {
        modalPrice.textContent += ` Includes Php ${currency.format(extraGuests * currentRoom.extraPrice)} in extra-person fees per night.`;
    }

    summaryNights.textContent = nights > 0 ? `${nights} ${nights === 1 ? "night" : "nights"}` : "Choose dates";
    summaryRoomRate.textContent = `Php ${currency.format(roomTotal)}`;
    summaryExtraFees.textContent = `Php ${currency.format(extraFees)}`;
    summaryTotal.textContent = `Php ${currency.format(grandTotal)}`;
}

function setGuestCount(value) {
    const guests = Math.min(currentRoom.maxGuests, Math.max(currentRoom.minGuests, Number(value)));
    guestCountInput.value = String(guests);
    guestCountInput.setAttribute("aria-valuetext", `${guests} ${guests === 1 ? "person" : "persons"}`);
    decreaseGuestsButton.disabled = guests <= currentRoom.minGuests;
    increaseGuestsButton.disabled = guests >= currentRoom.maxGuests;
    updateBookingSummary();
}

filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
        selectedCategory = button.dataset.filter;

        filterButtons.forEach((filterButton) => {
            filterButton.setAttribute("aria-pressed", String(filterButton === button));
        });

        applyRoomFilters();
    });
});

document.querySelectorAll("[data-show-all]").forEach((link) => {
    link.addEventListener("click", showAllRooms);
});

calendarDays.addEventListener("click", (event) => {
    const dayButton = event.target.closest(".calendar-day");
    if (!dayButton || dayButton.disabled) {
        return;
    }

    const selectedDate = dayButton.dataset.date;
    if (!availabilityCheckIn || availabilityCheckOut || selectedDate <= availabilityCheckIn) {
        availabilityCheckIn = selectedDate;
        availabilityCheckOut = "";
    } else {
        availabilityCheckOut = selectedDate;
    }

    renderAvailabilityCalendar();
    updateCalendarSelection();
});

document.querySelector("#previous-month").addEventListener("click", () => {
    calendarMonth.setMonth(calendarMonth.getMonth() - 1);
    renderAvailabilityCalendar();
});

document.querySelector("#next-month").addEventListener("click", () => {
    calendarMonth.setMonth(calendarMonth.getMonth() + 1);
    renderAvailabilityCalendar();
});

guestFilter.addEventListener("input", applyRoomFilters);
budgetFilter.addEventListener("change", applyRoomFilters);
ratingFilter.addEventListener("change", applyRoomFilters);
popularityFilter.addEventListener("change", applyRoomFilters);
sortFilter.addEventListener("change", applyRoomFilters);
amenityFilters.forEach((checkbox) => checkbox.addEventListener("change", applyRoomFilters));
document.querySelector("#reset-preferences").addEventListener("click", () => {
    guestFilter.value = "";
    budgetFilter.value = "";
    ratingFilter.value = "";
    popularityFilter.value = "";
    sortFilter.value = "recommended";
    amenityFilters.forEach((checkbox) => {
        checkbox.checked = false;
    });
    guestFilter.setCustomValidity("");
    applyRoomFilters();
});
openFiltersButton.addEventListener("click", openFilterModal);
closeFiltersButton.addEventListener("click", closeFilterModal);
document.querySelector("#apply-filters").addEventListener("click", closeFilterModal);
openAvailabilityButton.addEventListener("click", openAvailabilityModal);
closeAvailabilityButton.addEventListener("click", closeAvailabilityModal);
document.querySelector("#clear-availability").addEventListener("click", () => {
    availabilityCheckIn = "";
    availabilityCheckOut = "";
    availabilityRangeActive = false;
    availabilityCount.hidden = true;
    updateCalendarSelection();
    renderAvailabilityCalendar();
    applyRoomFilters();
});
applyAvailabilityButton.addEventListener("click", () => {
    availabilityRangeActive = true;
    availabilityCount.hidden = false;
    applyRoomFilters();
    closeAvailabilityModal();
});
filterModal.addEventListener("click", (event) => {
    if (event.target === filterModal) {
        closeFilterModal();
    }
});
availabilityModal.addEventListener("click", (event) => {
    if (event.target === availabilityModal) {
        closeAvailabilityModal();
    }
});

applyRoomFilters();

function closeBooking() {
    bookingModal.classList.remove("is-open");
    bookingModal.setAttribute("aria-hidden", "true");
    bookingMessage.hidden = true;
    lastFocusedElement?.focus();
}

document.querySelectorAll("[data-book-room]").forEach((button) => {
    button.addEventListener("click", () => {
        currentRoom = {
            name: button.dataset.bookRoom,
            price: Number(button.dataset.price),
            minGuests: Number(button.dataset.minGuests),
            defaultGuests: Number(button.dataset.defaultGuests || button.dataset.minGuests),
            includedGuests: Number(button.dataset.includedGuests),
            maxGuests: Number(button.dataset.maxGuests),
            extraPrice: Number(button.dataset.extraPrice),
            petCapacity: Number(button.dataset.petCapacity || 0)
        };

        modalTitle.textContent = `Book ${currentRoom.name}`;
        guestCountInput.min = String(currentRoom.minGuests);
        guestCountInput.max = String(currentRoom.maxGuests);
        guestLimit.textContent = currentRoom.extraPrice > 0
            ? `Rate covers up to ${currentRoom.includedGuests} persons; Php ${currency.format(currentRoom.extraPrice)} per person over ${currentRoom.includedGuests}, up to ${currentRoom.maxGuests}.`
            : `Rate includes up to ${currentRoom.includedGuests} persons; select ${currentRoom.minGuests} to ${currentRoom.maxGuests} persons.`;
        if (currentRoom.petCapacity > 0) {
            guestLimit.textContent += ` Maximum ${currentRoom.petCapacity} pets.`;
        }
        bookingForm.reset();
        petCountGroup.hidden = currentRoom.petCapacity === 0;
        petCountInput.disabled = currentRoom.petCapacity === 0;
        petCountInput.value = "0";
        bookingMessage.hidden = true;
        checkInInput.value = "";
        checkOutInput.value = "";
        updateDateLimits();
        if (availabilityRangeActive) {
            checkInInput.value = availabilityCheckIn;
            checkOutInput.value = availabilityCheckOut;
            updateDateLimits();
        }
        setGuestCount(currentRoom.defaultGuests);
        updateBookingSummary();
        lastFocusedElement = button;
        bookingModal.classList.add("is-open");
        bookingModal.setAttribute("aria-hidden", "false");
        document.querySelector("#guest-name").focus();
    });
});

closeModalButton.addEventListener("click", closeBooking);

bookingModal.addEventListener("click", (event) => {
    if (event.target === bookingModal) {
        closeBooking();
    }
});

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && availabilityModal.classList.contains("is-open")) {
        closeAvailabilityModal();
    }
    if (event.key === "Escape" && filterModal.classList.contains("is-open")) {
        closeFilterModal();
    }
    if (event.key === "Escape" && bookingModal.classList.contains("is-open")) {
        closeBooking();
    }
});

checkInInput.addEventListener("change", () => {
    updateDateLimits();
    updateBookingSummary();
});

checkOutInput.addEventListener("change", updateBookingSummary);
guestCountInput.addEventListener("change", () => setGuestCount(guestCountInput.value));
decreaseGuestsButton.addEventListener("click", () => setGuestCount(Number(guestCountInput.value) - 1));
increaseGuestsButton.addEventListener("click", () => setGuestCount(Number(guestCountInput.value) + 1));

bookingForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (getNightCount() <= 0) {
        checkOutInput.setCustomValidity("Check-out must be after check-in.");
        checkOutInput.reportValidity();
        return;
    }

    checkOutInput.setCustomValidity("");
    bookingMessage.textContent = "Your booking request is confirmed in this demo. No payment has been processed; please contact Bella Vista to finalize your reservation.";
    bookingMessage.hidden = false;
});

checkOutInput.addEventListener("input", () => checkOutInput.setCustomValidity(""));
