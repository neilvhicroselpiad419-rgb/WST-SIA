// Bella Vista — interactive first and second floor map.
const ACCOMMODATION_PAGE = '../accommodations/Accommodation.html';
const HOME_PAGE = '../landingpage/index.html';

// Coordinates refer to the 1648 x 928 displayed reference, then are converted
// into percentages so the hotspots stay aligned at every screen size.
const rooms = [
  {
    id: 'room-a',
    accommodationCardId: 'room-a',
    name: 'Room A',
    type: 'Standard',
    category: 'standard',
    capacity: '2–3 guests',
    rate: 3500,
    box: [53, 519, 367, 750],
    description:
      'Located at the lower end of the standard-room wing, Room A is a cozy retreat with a single large bed, a private bathroom, and a compact layout near the central stair and elevator area.',
    amenities: ['One large bed', 'Private bathroom', 'Bedside tables', 'Window-side view'],
    extra: '₱1,000 extra for the third guest.'
  },
  {
    id: 'room-b',
    accommodationCardId: 'room-b',
    name: 'Room B',
    type: 'Standard',
    category: 'standard',
    capacity: '2–3 guests',
    rate: 3500,
    box: [53, 312, 367, 516],
    description:
      'Room B sits in the middle of the standard-room wing. Its simple bedroom layout and private bathroom make it a comfortable base for couples or small groups.',
    amenities: ['One large bed', 'Private bathroom', 'Bedside storage', 'Compact room layout'],
    extra: '₱1,000 extra for the third guest.'
  },
  {
    id: 'room-c',
    accommodationCardId: 'room-c',
    name: 'Room C',
    type: 'Standard',
    category: 'standard',
    capacity: '2–3 guests',
    rate: 3500,
    box: [53, 91, 411, 309],
    description:
      'At the upper end of the standard-room wing, Room C offers a generous bedroom layout, private bathroom and a planted exterior feature beside the upper window area.',
    amenities: ['One large bed', 'Private bathroom', 'Bedside tables', 'Planted exterior feature'],
    extra: '₱1,000 extra for the third guest.'
  },
  {
    id: 'fr1',
    accommodationCardId: 'fr1',
    name: 'FR1',
    type: 'Family',
    category: 'family',
    capacity: '4–5 guests',
    rate: 6000,
    box: [754, 437, 1235, 598],
    description:
      'The lower family room is conveniently situated beside the pet-friendly sector. Two beds, a small kitchenette and a dining area make it a practical choice for families.',
    amenities: ['Two large beds', 'Private bathroom', 'Kitchenette', 'Dining table'],
    extra: 'Rate covers up to 5 guests.'
  },
  {
    id: 'fr2',
    accommodationCardId: 'fr2',
    name: 'FR2',
    type: 'Family',
    category: 'family',
    capacity: '4–5 guests',
    rate: 6000,
    box: [754, 268, 1235, 431],
    description:
      'In the middle of the family-room wing, FR2 features two beds and a dedicated dining nook. Its layout gives families a separate area to share snacks and spend time together.',
    amenities: ['Two large beds', 'Private bathroom', 'Kitchenette', 'Dining nook'],
    extra: 'Rate covers up to 5 guests.'
  },
  {
    id: 'fr3',
    accommodationCardId: 'fr3',
    name: 'FR3',
    type: 'Family',
    category: 'family',
    capacity: '4–5 guests',
    rate: 6000,
    box: [707, 85, 1235, 262],
    description:
      'FR3 occupies the upper family-room sector beside the guest lounge. Its two-bed arrangement, kitchenette and dining table provide a comfortable space for a family getaway.',
    amenities: ['Two large beds', 'Private bathroom', 'Kitchenette', 'Dining table', 'Planted exterior feature'],
    extra: 'Rate covers up to 5 guests.'
  },
  {
    id: 'pf1',
    accommodationCardId: 'pf1',
    name: 'PF1',
    type: 'Pet-Friendly',
    category: 'pet',
    capacity: '2 adults · up to 2 pets',
    rate: 3500,
    box: [715, 605, 1237, 785],
    description:
      'Designed for guests traveling with pets, PF1 has a large bed, a compact kitchenette, a private bathroom and a dedicated pet area with a pet bed and bowls.',
    amenities: ['One large bed', 'Private bathroom', 'Kitchenette', 'Pet bed', 'Pet bowls'],
    extra: 'Maximum 2 pets.'
  },
  {
    id: 'lounge',
    name: 'Guest Lounge',
    type: 'Shared Facility',
    category: 'common',
    box: [429, 100, 693, 487],
    description:
      'A central shared lounge where guests can relax, socialize or wait for their companions. The lounge includes a sectional sofa, a chair, a coffee table and indoor greenery.',
    amenities: ['Shared seating', 'Coffee table', 'Indoor plants', 'Central location']
  },
  {
    id: 'stairs',
    name: 'Stairs',
    type: 'Shared Facility',
    category: 'common',
    box: [425, 588, 568, 813],
    description:
      'The central staircase connects the second floor with the first floor, providing convenient access between the hotel accommodations and the main building facilities.',
    amenities: ['Access to first floor', 'Access to second floor']
  },
  {
    id: 'elevator',
    name: 'Elevator',
    type: 'Shared Facility',
    category: 'common',
    box: [575, 646, 703, 810],
    description:
      'The elevator is located next to the staircase in the central circulation area, providing a convenient route between floors.',
    amenities: ['Central location', 'Vertical floor access']
  }
];

// First-floor facilities. Coordinates: 1408 × 1056 reference.
const firstFloor = [
  {
    "id": "f1-admin",
    "name": "Admin / Management Office",
    "type": "Staff-only",
    "box": [
      107,
      188,
      267,
      294
    ],
    "description": "The hotel administration office is reserved for management and authorized staff. Guests requiring assistance may approach the reception desk.",
    "amenities": [
      "Management workspace",
      "Staff access only"
    ],
    "category": "staff"
  },
  {
    "id": "f1-security",
    "name": "Security / Staff Office",
    "type": "Staff-only",
    "box": [
      276,
      188,
      390,
      286
    ],
    "description": "The security and staff office supports hotel operations and guest safety. Access is restricted to authorized personnel.",
    "amenities": [
      "Security desk",
      "Staff workspace"
    ],
    "category": "staff"
  },
  {
    "id": "f1-storage",
    "name": "Storage / Utility Room",
    "type": "Staff-only",
    "box": [
      400,
      188,
      548,
      286
    ],
    "description": "A service room for hotel supplies and utility equipment. This area is not open to guests.",
    "amenities": [
      "Supply storage",
      "Utility space"
    ],
    "category": "staff"
  },
  {
    "id": "f1-service",
    "name": "Service Corridor",
    "type": "Staff-only",
    "box": [
      558,
      206,
      913,
      257
    ],
    "description": "The service corridor connects the staff and event preparation areas behind the main guest spaces.",
    "amenities": [
      "Service circulation",
      "Authorized staff only"
    ],
    "category": "staff"
  },
  {
    "id": "f1-prep",
    "name": "Event Prep / Backstage",
    "type": "Staff-only",
    "box": [
      1195,
      194,
      1364,
      296
    ],
    "description": "A preparation and storage area behind the event hall for event personnel and equipment.",
    "amenities": [
      "Event preparation",
      "Backstage storage"
    ],
    "category": "staff"
  },
  {
    "id": "f1-restroom-men",
    "name": "Public Restroom (Men)",
    "type": "Guest facility",
    "box": [
      108,
      330,
      229,
      433
    ],
    "description": "The public men’s restroom is located beside the café and lobby area.",
    "amenities": [
      "Toilet facilities",
      "Washbasins"
    ],
    "category": "common"
  },
  {
    "id": "f1-restroom-women",
    "name": "Public Restroom (Women)",
    "type": "Guest facility",
    "box": [
      237,
      330,
      368,
      433
    ],
    "description": "The public women’s restroom is located next to the men’s restroom near the lobby.",
    "amenities": [
      "Toilet facilities",
      "Washbasins"
    ],
    "category": "common"
  },
  {
    "id": "f1-cafe",
    "name": "Café Nook & Lounge",
    "type": "Dining",
    "box": [
      74,
      444,
      328,
      691
    ],
    "description": "A relaxed café corner with a service counter and small tables for guests to enjoy refreshments and conversation.",
    "amenities": [
      "Café counter",
      "Table seating",
      "Lounge area"
    ],
    "category": "common"
  },
  {
    "id": "f1-reception",
    "name": "Reception / Front Desk",
    "type": "Guest services",
    "box": [
      437,
      345,
      674,
      526
    ],
    "description": "The main reception desk is where guests can check in, check out, and ask about their reservations.",
    "amenities": [
      "Check-in assistance",
      "Reservation inquiries",
      "Front desk"
    ],
    "category": "common"
  },
  {
    "id": "f1-stairs",
    "name": "Stair Access",
    "type": "Guest facility",
    "box": [
      607,
      266,
      725,
      422
    ],
    "description": "The central staircase leads upstairs to the second-floor guest rooms.",
    "amenities": [
      "Access to second floor",
      "Central circulation"
    ],
    "category": "common"
  },
  {
    "id": "f1-elevator",
    "name": "Elevator Access",
    "type": "Guest facility",
    "box": [
      737,
      329,
      821,
      419
    ],
    "description": "The elevator provides vertical access between the first-floor facilities and second-floor accommodations.",
    "amenities": [
      "Access to second floor",
      "Central location"
    ],
    "category": "common"
  },
  {
    "id": "f1-concierge",
    "name": "Concierge / Information Desk",
    "type": "Guest services",
    "box": [
      735,
      434,
      890,
      548
    ],
    "description": "The concierge desk assists guests with information about the hotel, its facilities and their stay.",
    "amenities": [
      "Guest information",
      "Visitor assistance"
    ],
    "category": "common"
  },
  {
    "id": "f1-lobby",
    "name": "Lobby & Waiting Lounge",
    "type": "Guest facility",
    "box": [
      335,
      548,
      890,
      702
    ],
    "description": "The central lobby welcomes visitors with comfortable seating, indoor greenery and space to wait before check-in or an event.",
    "amenities": [
      "Lounge seating",
      "Central floral display",
      "Reception access"
    ],
    "category": "common"
  },
  {
    "id": "f1-stage",
    "name": "Stage / Platform",
    "type": "Event facility",
    "box": [
      924,
      269,
      1185,
      366
    ],
    "description": "The stage is part of the event hall and provides a focal point for presentations, ceremonies and celebrations.",
    "amenities": [
      "Raised platform",
      "Event presentation area"
    ],
    "category": "event"
  },
  {
    "id": "f1-event-hall",
    "accommodationCardId": "event-hall-card",
    "name": "Event Hall",
    "type": "Event facility",
    "box": [
      903,
      370,
      1262,
      703
    ],
    "description": "A flexible events venue for intimate celebrations, meetings and gatherings, with round-table seating and a stage. The base rate includes up to 30 guests, with an absolute maximum of 40.",
    "amenities": [
      "Round-table seating",
      "Stage / platform",
      "Nearby event restrooms",
      "Backstage preparation area"
    ],
    "category": "event",
    "capacity": "Up to 40 guests",
    "rate": 15000,
    "extra": "₱500 per extra guest beyond 30, up to 40 guests."
  },
  {
    "id": "f1-event-restroom-men",
    "name": "Event Restroom (Men)",
    "type": "Guest facility",
    "box": [
      1277,
      308,
      1366,
      428
    ],
    "description": "A dedicated men’s restroom serving the event hall.",
    "amenities": [
      "Toilet facilities",
      "Washbasins"
    ],
    "category": "common"
  },
  {
    "id": "f1-event-restroom-women",
    "name": "Event Restroom (Women)",
    "type": "Guest facility",
    "box": [
      1277,
      439,
      1366,
      558
    ],
    "description": "A dedicated women’s restroom serving the event hall.",
    "amenities": [
      "Toilet facilities",
      "Washbasins"
    ],
    "category": "common"
  },
  {
    "id": "f1-souvenir",
    "name": "Souvenir Boutique",
    "type": "Shopping",
    "box": [
      105,
      714,
      328,
      840
    ],
    "description": "A small boutique near the entrance for browsing souvenirs and keepsakes.",
    "amenities": [
      "Gift displays",
      "Souvenir merchandise"
    ],
    "category": "common"
  },
  {
    "id": "f1-crafts",
    "name": "Local Crafts Boutique",
    "type": "Shopping",
    "box": [
      337,
      714,
      535,
      840
    ],
    "description": "A boutique featuring locally inspired crafts and decorative items.",
    "amenities": [
      "Craft displays",
      "Local gift items"
    ],
    "category": "common"
  },
  {
    "id": "f1-fashion",
    "name": "Fashion Boutique",
    "type": "Shopping",
    "box": [
      787,
      714,
      1035,
      840
    ],
    "description": "A retail space for browsing clothing and accessories during a hotel visit.",
    "amenities": [
      "Clothing displays",
      "Accessories"
    ],
    "category": "common"
  },
  {
    "id": "f1-wellness",
    "name": "Wellness / Gift Boutique",
    "type": "Shopping",
    "box": [
      1046,
      714,
      1286,
      840
    ],
    "description": "A boutique for wellness-inspired gifts and personal-care items.",
    "amenities": [
      "Gift displays",
      "Wellness merchandise"
    ],
    "category": "common"
  },
  {
    "id": "f1-entrance",
    "name": "Main Entrance / Drop-off",
    "type": "Arrival",
    "box": [
      560,
      845,
      759,
      1026
    ],
    "description": "The main arrival point leads into the lobby, with a drop-off area in front of the hotel.",
    "amenities": [
      "Guest arrival",
      "Vehicle drop-off",
      "Lobby access"
    ],
    "category": "common"
  }
];

let activeFloor = "first";

const pesos = new Intl.NumberFormat('en-PH', {
  style: 'currency',
  currency: 'PHP',
  maximumFractionDigits: 0
});
const money = amount => pesos.format(amount);
const byId = id => document.getElementById(id);
const dialog = byId('room-dialog');
const hotspotLayer = byId('hotspots');
let lastTrigger = null;
let selectedHotspot = null;

// Let the user change the home path without editing the HTML.
document.querySelectorAll('.brand,.back-link').forEach(a => (a.href = HOME_PAGE));

// Photo filenames are editable. Missing images are skipped.
const roomPhotos = {
  'room-a': ['Bedroom Interior', 'Room View', 'Private Bathroom'],
  'room-b': ['Bedroom Interior', 'Room View', 'Private Bathroom'],
  'room-c': ['Bedroom Interior', 'Balcony View', 'Private Bathroom'],
  fr1: ['Family Bedroom', 'Dining Area', 'Private Bathroom'],
  fr2: ['Family Bedroom', 'Kitchenette', 'Private Bathroom'],
  fr3: ['Family Bedroom', 'Dining Area', 'Private Bathroom'],
  pf1: ['Pet-Friendly Bedroom', 'Kitchenette', 'Balcony and Pet Area'],
  'f1-cafe': ['Café Counter', 'Lounge Seating', 'Dining Area'],
  'f1-souvenir': ['Souvenir Displays', 'Keepsake Collection', 'Gift Shelves'],
  'f1-crafts': ['Handwoven Crafts', 'Local Textiles', 'Artisan Displays'],
  'f1-fashion': ['Clothing Collection', 'Fashion Displays', 'Accessories'],
  'f1-wellness': ['Wellness Products', 'Personal Care Collection', 'Gift Display'],
  'f1-event-hall': ['Event Hall Interior', 'Stage and Seating', 'Celebration Setup'],
  'f1-lobby': ['Lobby Interior', 'Reception Desk', 'Waiting Lounge'],
  'f1-entrance': ['Main Entrance', 'Hotel Arrival Area', 'Covered Drop-off'],
  'f1-stairs': ['Staircase Interior'],
  'f1-elevator': ['Elevator Interior', 'Elevator Lobby']
};
const photoImage = byId('detail-image');
const photoCounter = byId('photo-counter');
const photoLabel = byId('detail-image-label');
const thumbnails = byId('gallery-thumbnails');
const prevPhoto = byId('prev-photo');
const nextPhoto = byId('next-photo');
let currentPhotos = [];
let currentPhotoIndex = 0;
let currentRoomName = '';
let galleryVersion = 0;

function showPhoto(index) {
  const total = currentPhotos.length;
  if (!total) return;
  currentPhotoIndex = ((index % total) + total) % total;
  const photo = currentPhotos[currentPhotoIndex];
  photoImage.src = photo.src;
  photoImage.alt = `${currentRoomName} - ${photo.label}`;
  photoLabel.textContent = photo.label;
  photoCounter.textContent = `${currentPhotoIndex + 1} / ${total}`;
  photoImage.style.animation = 'none';
  void photoImage.offsetWidth;
  photoImage.style.animation = '';
  thumbnails.querySelectorAll('.gallery-thumb').forEach((thumb, i) => {
    const active = i === currentPhotoIndex;
    thumb.classList.toggle('active', active);
    thumb.setAttribute('aria-pressed', String(active));
  });
}

function renderGallery() {
  thumbnails.replaceChildren();
  const multiple = currentPhotos.length > 1;
  prevPhoto.hidden = nextPhoto.hidden = photoCounter.hidden = thumbnails.hidden = !multiple;
  if (multiple) {
    currentPhotos.forEach((photo, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'gallery-thumb';
      button.setAttribute('aria-label', `View ${photo.label}`);
      const img = document.createElement('img');
      img.src = photo.src;
      img.alt = photo.label;
      img.draggable = false;
      button.append(img);
      button.addEventListener('click', () => showPhoto(index));
      thumbnails.append(button);
    });
  }
  showPhoto(0);
}

function checkPhoto(photo) {
  return new Promise(resolve => {
    const image = new Image();
    image.onload = () => resolve(photo);
    image.onerror = () => resolve(null);
    image.src = photo.src;
  });
}

async function loadRoomGallery(room) {
  const version = ++galleryVersion;
  currentRoomName = room.name;
  const floorPlan = { src: `assets/${room.id}.webp`, label: 'Floor Plan Preview' };
  currentPhotos = [floorPlan];
  renderGallery();
  const photos = (roomPhotos[room.id] || []).map((label, i) => ({
    src: `assets/${room.id}-${i + 1}.png`,
    label: `${label} (Concept)`
  }));
  if (!photos.length) return;
  const results = await Promise.all(photos.map(checkPhoto));
  if (version !== galleryVersion) return;
  currentPhotos = [...results.filter(Boolean), floorPlan];
  renderGallery();
}
prevPhoto.addEventListener('click', () => showPhoto(currentPhotoIndex - 1));
nextPhoto.addEventListener('click', () => showPhoto(currentPhotoIndex + 1));
dialog.addEventListener('keydown', event => {
  if (currentPhotos.length < 2) return;
  if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
    event.preventDefault();
    showPhoto(currentPhotoIndex + (event.key === 'ArrowRight' ? 1 : -1));
  }
});
let touchStartX = 0;
let touchStartY = 0;
photoImage.addEventListener('touchstart', event => {
  touchStartX = event.changedTouches[0].screenX;
  touchStartY = event.changedTouches[0].screenY;
}, { passive: true });
photoImage.addEventListener('touchend', event => {
  const dx = touchStartX - event.changedTouches[0].screenX;
  const dy = touchStartY - event.changedTouches[0].screenY;
  if (currentPhotos.length > 1 && Math.abs(dx) >= 45 && Math.abs(dx) > Math.abs(dy)) {
    showPhoto(currentPhotoIndex + (dx > 0 ? 1 : -1));
  }
}, { passive: true });

function openDetails(room, trigger) {
  lastTrigger = trigger;
  if (selectedHotspot) selectedHotspot.classList.remove('selected');
  selectedHotspot = byId(`hotspot-${room.id}`);
  selectedHotspot.classList.add('selected');
  byId('detail-title').textContent = room.name;
  byId('detail-type').textContent = room.type;
  byId('detail-description').textContent = room.description;
  loadRoomGallery(room);
  const facts = byId('detail-facts');
  facts.replaceChildren();
  const floorName = activeFloor === 'first' ? 'First floor' : 'Second floor';
  const bookable = Object.prototype.hasOwnProperty.call(room, 'rate');
  const factValues = bookable ? [room.capacity, floorName, room.type] : [floorName, room.type];
  factValues.forEach(value => {
    const span = document.createElement('span');
    span.className = 'fact';
    span.textContent = value;
    facts.append(span);
  });
  const amenities = byId('detail-amenities');
  amenities.replaceChildren();
  room.amenities.forEach(value => {
    const li = document.createElement('li');
    li.textContent = value;
    amenities.append(li);
  });
  const rateBox = byId('detail-rate-box');
  const book = byId('book-room');
  const common = !bookable;
  rateBox.hidden = common;
  book.hidden = common;
  if (!common) {
    byId('detail-rate').textContent = room.rate === null ? 'To be confirmed' : money(room.rate);
    byId('detail-extra').textContent = room.extra;
    const url = new URL(ACCOMMODATION_PAGE, window.location.href);
    url.hash = room.accommodationCardId;
    book.textContent = room.id === 'f1-event-hall' ? 'Book event hall →' : 'Book this room →';
    book.href = url.href;
  }
  byId('detail-note').textContent = common
    ? room.category === 'staff'
      ? 'Staff-only area. Please ask reception for assistance.'
      : 'Floor plan preview and, where available, illustrative interior concepts.'
    : room.id === 'f1-event-hall'
        ? 'Maximum 40 guests. Continue to the accommodations page to book the event hall.'
        : 'Continue to the accommodations page to book this room.';
  if (!dialog.open) dialog.showModal();
  byId('close-detail').focus();
}

// Render a floor and its independently positioned hotspots.
function selectFloor(floor) {
  if (dialog.open) dialog.close();
  activeFloor = floor;
  selectedHotspot = null;
  lastTrigger = null;
  const first = floor === 'first';
  const entries = first ? firstFloor : rooms;
  const [w, h] = first ? [1408, 1056] : [1648, 928];
  const image = byId('plan-image');
  image.src = `assets/${first ? 'first' : 'second'}-floor.webp`;
  image.width = first ? 1448 : 1672;
  image.height = first ? 1086 : 941;
  image.alt = `Bella Vista ${first ? 'first' : 'second'}-floor plan`;
  byId('map-scroll').setAttribute(
    'aria-label',
    `${first ? 'First' : 'Second'} floor map; scroll horizontally on smaller screens`
  );
  byId('map-title').textContent = `${first ? 'First' : 'Second'} floor plan`;
  document.querySelectorAll('.floor-button').forEach(button => {
    const active = button.dataset.floor === floor;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  const legend = first
    ? [
        ['common', 'Guest facilities'],
        ['event', 'Event facilities'],
        ['staff', 'Staff-only areas']
      ]
    : [
        ['standard', 'Standard rooms'],
        ['family', 'Family rooms'],
        ['pet', 'Pet-friendly'],
        ['common', 'Shared facilities']
      ];
  const legendEl = byId('map-legend');
  legendEl.replaceChildren();
  legend.forEach(([category, label]) => {
    const item = document.createElement('span');
    const dot = document.createElement('span');
    dot.className = `legend-dot ${category}`;
    item.append(dot, document.createTextNode(label));
    legendEl.append(item);
  });
  const tip = document.createElement('span');
  tip.className = 'map-tip';
  tip.textContent = 'On mobile, swipe sideways to explore.';
  legendEl.append(tip);
  hotspotLayer.replaceChildren();
  entries.forEach(room => {
    const [x1, y1, x2, y2] = room.box;
    const button = document.createElement('button');
    button.type = 'button';
    button.id = `hotspot-${room.id}`;
    button.className = `hotspot ${room.category}`;
    button.setAttribute('aria-label', `View ${room.name} details`);
    button.title = `${room.name} — ${room.type}`;
    Object.assign(button.style, {
      left: `${(x1 / w) * 100}%`,
      top: `${(y1 / h) * 100}%`,
      width: `${((x2 - x1) / w) * 100}%`,
      height: `${((y2 - y1) / h) * 100}%`
    });
    button.addEventListener('click', () => openDetails(room, button));
    hotspotLayer.append(button);
  });
  byId('map-scroll').scrollLeft = 0;
}
document.querySelectorAll('.floor-button').forEach(button => {
  button.addEventListener('click', () => selectFloor(button.dataset.floor));
});
selectFloor('first');

byId('close-detail').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => {
  if (event.target === dialog) dialog.close();
});
dialog.addEventListener('close', () => {
  galleryVersion++;
  if (selectedHotspot) selectedHotspot.classList.remove('selected');
  if (lastTrigger) lastTrigger.focus({ preventScroll: true });
});
byId('reset-map').addEventListener('click', () =>
  byId('map-scroll').scrollTo({
    left: 0,
    behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'
  })
);
